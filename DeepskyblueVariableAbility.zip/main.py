def bubble_sort(lista):
    n = len(lista)
    for i in range(n):
        for j in range(0, n-i-1):
            if lista[j] > lista[j + 1]:
                temp = lista[j]
                lista[j] = lista[j + 1]
                lista[j + 1] = temp

# Leer lista de números
numeros = [64, 34, 25, 12, 22, 11, 90]

# Llamar a la función de ordenamiento
bubble_sort(numeros)

# Imprimir lista ordenada
print("Lista ordenada:", numeros)
