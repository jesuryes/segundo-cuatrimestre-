# Inicio
# Leer num1
num1 = float(input("Ingrese el primer número: "))

# Leer num2
num2 = float(input("Ingrese el segundo número: "))

# suma = num1 + num2
suma = num1 + num2

# Imprimir suma
print("La suma de los dos números es:", suma)
# Fin
